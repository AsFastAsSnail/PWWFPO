package lab7;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.StringTokenizer;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.filechooser.FileSystemView;
import javax.swing.text.BadLocationException;
import javax.swing.text.StyledDocument;

public class TextPanel extends JPanel{
	private JTextPane panTekst;
	private StyledDocument doc;
	private String tekst, tekstDoPanelu, check;
	private	StringTokenizer check2, tekst2;
	private JScrollPane scroll;
	public TextPanel() {
		setLayout(new BorderLayout());
		panTekst = new JTextPane();
		panTekst.setText(" ");
		doc = panTekst.getStyledDocument();
		scroll = new JScrollPane(panTekst);
		scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		scroll.setPreferredSize(new Dimension(getWidth(),getHeight()));
		scroll.setMinimumSize(new Dimension(100,100));
		add(scroll);
	}
	public void SelectFile() throws IOException {
		JFileChooser chooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
		int retVal = chooser.showOpenDialog(null);
		if(retVal == JFileChooser.APPROVE_OPTION) {
			File selectedFile = chooser.getSelectedFile();
			try {
				BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream(selectedFile),Charset.forName("UTF-8").newDecoder()));
				StringBuilder build = new StringBuilder();
				while((tekst = input.readLine()) != null)build.append(tekst + System.getProperty("line.separator"));
				tekst = build.toString();
				input.close();
			} catch (UnsupportedEncodingException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	        tekstDoPanelu = tekst.replaceAll("ó", "?");
	        tekstDoPanelu = tekstDoPanelu.replaceAll("rz", "?");
	        tekstDoPanelu = tekstDoPanelu.replaceAll("u", "?");
	        tekstDoPanelu = tekstDoPanelu.replaceAll("ż", "?");
	      	tekstDoPanelu = tekstDoPanelu.replaceAll("ch", "?");
	        tekstDoPanelu = tekstDoPanelu.replaceAll("h", "?");
	        System.out.println(tekst);
			panTekst.setText(tekstDoPanelu);
			
			
		}
		
	}
	public void Check() {
		check = panTekst.getText();
		if(check.contentEquals(tekst)) {
			JOptionPane.showMessageDialog(null, "Dobrze");
		}
		if(!check.contentEquals(tekst)) {
			StringBuilder doOkna = new StringBuilder();
			check2 = new StringTokenizer(check);
			tekst2 = new StringTokenizer(tekst);
			while(tekst2.hasMoreTokens()){
				String check3 = check2.nextToken();
				if(!tekst2.nextToken().contentEquals(check3)) {
					doOkna.append(check3 + "\n");
				}
				else {
					
				}
			}
			String wiad = doOkna.toString();
			JOptionPane.showMessageDialog(null, wiad);
			/*check2 = new StringTokenizer(check);
			tekst2 = new StringTokenizer(tekst);
			while(tekst2.hasMoreTokens()) {
				try {
					String check3 = check2.nextToken();
					tekst2.nextToken().contains(check3);
					throw new OrtException(check3);
				}
				catch(OrtException e) {
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
			}*/
		}
	}
	public void Save() {
		JFileChooser chooser = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
		int retVal = chooser.showOpenDialog(null);
		if(retVal == JFileChooser.APPROVE_OPTION) {
			File plikDoZapisu = chooser.getSelectedFile();
			try {
				OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(plikDoZapisu), Charset.forName("UTF-8").newEncoder());
				try {
					writer.append(panTekst.getText());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					writer.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	public void ChangeFontItalic(String font) {
		Font newfont = new Font(font, Font.ITALIC, 20);
		panTekst.setFont(newfont);
	}
	public void ChangeFontBold(String font) {
		Font newfont = new Font(font, Font.BOLD, 20);
		panTekst.setFont(newfont);
	}
}

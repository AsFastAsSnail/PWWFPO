package bilard;

import java.awt.*;
import java.awt.geom.Line2D;

import javax.swing.*;

public class Kij extends Object{
	
	private float longX, longY, shortX, shortY, length, centerX, centerY, distance;
	private double degrees, radians;
	private int width;
	
	public Kij(float r, float R, float CentX, float CentY) {
		length = r;
		distance = R;
		degrees = 0;
		width = 7;
		centerX = CentX;
		centerY = CentY;
		radians = Math.toRadians(degrees);
		longX = centerX - (float) ((distance + length)*Math.cos(radians));
		shortX = centerX - (float) ((distance)*Math.cos(radians));
		longY = centerY - (float) ((distance + length)*Math.sin(radians));
		shortY = centerY - (float) ((distance)*Math.sin(radians));
	}
	public void getAngle(int ang) {
		degrees = ang;
		radians = Math.toRadians(degrees);
		longX = centerX - (float) ((distance + length)*Math.cos(radians));
		shortX = centerX - (float) ((distance)*Math.cos(radians));
		longY = centerY - (float) ((distance + length)*Math.sin(radians));
		shortY = centerY - (float) ((distance)*Math.sin(radians));
	}
	public void setCenter(float CentX, float CentY) {
		centerX = CentX;
		centerY = CentY;
	}
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.BLACK);
		g2.setStroke(new BasicStroke(width));
		g2.draw(new Line2D.Float(shortX, shortY, longX, longY));
	}
}

package bilard;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.util.List;

public class Bila {
	
	private float  diametar, wspX, wspY;
	private int numer;
	private double vX, vY, Ex, Ey, aX, aY, masa, radians;
	boolean logiczna = false;
	boolean zderzenie = false;
	
	public Bila() {
		
	}
	
	public Bila(float diam, float x, float y, double mass) {
		zderzenie = false;
		diametar = diam;
		wspX = x;
		wspY = y;
		vX = 0;
		vY = 0;
		aX = 0;
		aY = 0;
		masa = mass;
		Ex = 0;
		Ey = 0;
	}
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
        Ellipse2D.Double circle = new Ellipse2D.Double(getX() - getDiametar() / 2, getY() - getDiametar() / 2, getDiametar(), getDiametar());
        g2.fill(circle);
	}

    public boolean move(int width, int height, double Tarcie, int szerokoscBand) {
    	
    	logiczna = true;
    	
        setX((float) (getX() + getxSpeed()));

        if (getX() - getDiametar() / 2 < 0 + szerokoscBand) {
            setX(szerokoscBand + getDiametar() / 2);
            setxSpeed(-getxSpeed());
        } else if (getX() + getDiametar() / 2 > width - szerokoscBand) {
            setxSpeed(-getxSpeed());
            setX(width - szerokoscBand - getDiametar() / 2);
        }
        if(vX < 0)aX = -Math.abs(aX*0.9);
        if(vX > 0)aX = Math.abs(aX*0.9);
        setxSpeed(vX*(1-Tarcie) + aX);
       

        setY((float) (getY() + getySpeed()));

        if (getY() - getDiametar() / 2 < 0+szerokoscBand) {
        	setY(szerokoscBand + getDiametar() / 2);
            setySpeed(-getySpeed());
        } else if (getY() + getDiametar() / 2 > height - szerokoscBand) {
            setY(height - szerokoscBand - getDiametar() / 2);
            setySpeed(-getySpeed());
        }
        if(vY < 0)aY = -Math.abs(aY*0.9);
        if(vY > 0)aY = Math.abs(aY*0.9);
        setySpeed(vY*(1-Tarcie) + aY);
        
        
        if(vX > 0 && vX < 0.1) {
        	vX = 0;
        	logiczna = false;
        	//zderzenie = false;
        	
        }
        if(vX < 0 && vX > -0.1) {
        	vX = 0;
        	logiczna = false;
        	//zderzenie = false;
        	
        }
        if(vY > 0 && vY < 0.1) {
        	vY = 0;
        	logiczna = false;
        	//zderzenie = false;
        	
        }
        if(vY < 0 && vY > -0.1) {
        	vY = 0;
        	logiczna = false;
        	//zderzenie = false;
        	
        }
        return logiczna;
    }
    public void Hit(float force2, float kat) {
    	radians = Math.toRadians(kat);
    	//aX = (double) (force2/masa)*Math.cos(radians);
    	//aY = (double) (force2/masa)*Math.sin(radians);
    	vX = (double) Math.sqrt(force2*2/masa)*Math.cos(radians);
    	vY = (double) Math.sqrt(force2*2/masa)*Math.sin(radians);
    }
    
    
    public double getxSpeed() {
        return vX;
    }

    
    public void setxSpeed(double xSpeed) {
        vX = xSpeed;
    }

    
    public double getySpeed() {
        return vY;
    }

    
    public void setySpeed(double ySpeed) {
    	vY = ySpeed;
    }

    
    public float getX() {
        return wspX;
    }

    
    public void setX(float x) {
        wspX = x;
    }

    
    public float getY() {
        return wspY;
    }

    
    public void setY(float y) {
        wspY = y;
    }

    
    public float getDiametar() {
        return diametar;
    }

    
    public void setDiametar(float diam) {
        diametar = diam;
    }
    public double getMass() {
    	return masa;
    }
    public double returnAX() {
    	return aX;
    }
    public double returnAY() {
    	return aY;
    }
}

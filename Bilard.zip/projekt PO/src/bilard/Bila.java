package bilard;

public class Bila {
	Integer numer, promien, wspx, wspy;
	Double vx, vy, Ex, Ey, ax, ay;
	public Bila() {

		
	}

}

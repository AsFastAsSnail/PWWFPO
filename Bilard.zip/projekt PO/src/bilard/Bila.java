package bilard;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

public class Bila {
	
	private float  diametar, wspX, wspY;
	private int numer;
	private double vX, vY, Ex, Ey, aX, aY, masa, radians;
	
	public Bila(float diam, float x, float y, double mass) {
		diametar = diam;
		wspX = x;
		wspY = y;
		vX = 0;
		vY = 0;
		aX = 0;
		aY = 0;
		masa = mass;
		Ex = 0;
		Ey = 0;
	}
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
        Ellipse2D.Double circle = new Ellipse2D.Double(getX() - getDiametar() / 2, getY() - getDiametar() / 2, getDiametar(), getDiametar());
        g2.fill(circle);
	}

    public void move(int width, int height, double Tarcie) {
        setX((float) (getX() + getxSpeed()));

        if (getX() - getDiametar() / 2 < 0) {
            setX(getDiametar() / 2);
            setxSpeed(-getxSpeed());
        } else if (getX() + getDiametar() / 2 > width) {
            setxSpeed(-getxSpeed());
            setX(width - getDiametar() / 2);
        }
        if(vX < 0)aX = -Math.abs(aX*0.9);
        if(vX > 0)aX = Math.abs(aX*0.9);
        setxSpeed(vX*(1-Tarcie) + aX);
       

        setY((float) (getY() + getySpeed()));

        if (getY() - getDiametar() / 2 < 0) {
            setySpeed(-getySpeed());
        } else if (getY() + getDiametar() / 2 > height) {
            setY(height - getDiametar() / 2);
            setySpeed(-getySpeed());
        }
        if(vY < 0)aY = -Math.abs(aX*0.9);
        if(vY > 0)aY = Math.abs(aY*0.9);
        setySpeed(vY*(1-Tarcie) + aY);
        if(vX > 0 && vX < 0.1)vX = 0;
        if(vX < 0 && vX > -0.1)vX = 0;
        if(vY > 0 && vY < 0.1)vY = 0;
        if(vY < 0 && vY > -0.1)vY = 0;
    }
    public void Hit(int Force, int angle) {
    	radians = Math.toRadians(angle);
    	aX = (double) (Force/masa)*Math.cos(radians);
    	aY = (double) (Force/masa)*Math.asin(radians);
    	vX = (double) Force*Math.cos(radians);
    	vY = (double) Force*Math.sin(radians);
    }
    public double getxSpeed() {
        return vX;
    }

    
    public void setxSpeed(double xSpeed) {
        vX = xSpeed;
    }

    
    public double getySpeed() {
        return vY;
    }

    
    public void setySpeed(double ySpeed) {
    	vY = ySpeed;
    }

    
    public float getX() {
        return wspX;
    }

    
    public void setX(float x) {
        wspX = x;
    }

    
    public float getY() {
        return wspY;
    }

    
    public void setY(float y) {
        wspY = y;
    }

    
    public float getDiametar() {
        return diametar;
    }

    
    public void setDiametar(float diam) {
        diametar = diam;
    }
}

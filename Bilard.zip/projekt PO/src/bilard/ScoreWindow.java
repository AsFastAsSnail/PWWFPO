package bilard;

import java.awt.GridLayout;
import java.util.concurrent.TimeUnit;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class ScoreWindow extends JPanel {

	private JLabel time, score;
	private int pkt;
	public ScoreWindow() {
		pkt = 0;
		setLayout(new GridLayout(1,2));
		time = new JLabel("czas:");
		add(time);
		score = new JLabel("wynik: " + pkt);
		add(score);
	}
	public void addScore(int Pkt) {
		pkt += Pkt;
		score.setText("wynik: " + pkt);
	}
	public void runThread() {
		Time timeThread = new Time();
		timeThread.start();
	}
	class Time extends Thread {
		public void run() {
			int j = 1;
			while(true) {
				for(int i = 1;i < 60;i++) {
					time.setText("czas: " + i + "s");
					try {
						TimeUnit.SECONDS.sleep(1);
						System.out.println(" . ");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				while(true) {
					for(int i = 0;i < 60;i++) {
						time.setText("czas: " + j + ":" + i + " min");
						try {
							TimeUnit.SECONDS.sleep(1);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					j++;
				}
			}
		}
	}
}

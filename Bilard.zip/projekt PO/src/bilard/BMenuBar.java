package bilard;

import java.awt.Color;

import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import bilard.GameWindow.Exit;

public class BMenuBar extends JMenuBar{
	
	JMenu menu, masa, tarcie, energia;
	JMenuItem mExit, masa1, masa2, masa3, tarcie1, tarcie2, tarcie3, energia1, energia2, energia3;

	public BMenuBar() {
		menu = new JMenu("Menu");
		add(menu);
		setBackground(new Color(38,38,38));
		menu.setForeground(new Color(200,200,200));
		menu.setBackground(new Color(38,38,38));
		mExit = new JMenuItem("Exit");
		mExit.setForeground(new Color(200,200,200));
		mExit.setBackground(new Color(38,38,38));
		menu.add(mExit);
		
		masa = new JMenu("Masa");
		add(masa);
		masa.setForeground(new Color(200,200,200));
		masa.setBackground(new Color(38,38,38));
		masa1 = new JMenuItem("Masa 1");
		masa1.setBackground(new Color(38,38,38));
		masa1.setForeground(new Color(200,200,200));
		masa2 = new JMenuItem("Masa 2");
		masa2.setBackground(new Color(38,38,38));
		masa2.setForeground(new Color(200,200,200));
		masa3 = new JMenuItem("Masa 3");
		masa3.setBackground(new Color(38,38,38));
		masa3.setForeground(new Color(200,200,200));
		masa.add(masa1);
		masa.add(masa2);
		masa.add(masa3);
		
		tarcie = new JMenu("Tarcie");
		add(tarcie);
		tarcie.setForeground(new Color(200,200,200));
		tarcie.setBackground(new Color(38,38,38));
		tarcie1 = new JMenuItem("Tarcie 1");
		tarcie1.setBackground(new Color(38,38,38));
		tarcie1.setForeground(new Color(200,200,200));
		tarcie2 = new JMenuItem("Tarcie 2");
		tarcie2.setBackground(new Color(38,38,38));
		tarcie2.setForeground(new Color(200,200,200));
		tarcie3 = new JMenuItem("Tarcie 3");
		tarcie3.setBackground(new Color(38,38,38));
		tarcie3.setForeground(new Color(200,200,200));
		tarcie.add(tarcie1);
		tarcie.add(tarcie2);
		tarcie.add(tarcie3);
		
		energia = new JMenu("Przekaz Energii");
		add(energia);
		energia.setForeground(new Color(200,200,200));
		energia.setBackground(new Color(38,38,38));
		energia1 = new JMenuItem("Współczynnik 1");
		energia1.setBackground(new Color(38,38,38));
		energia1.setForeground(new Color(200,200,200));
		energia2 = new JMenuItem("Współczynnik 2");
		energia2.setForeground(new Color(200,200,200));
		energia2.setBackground(new Color(38,38,38));
		energia3 = new JMenuItem("Współczunnik 3");
		energia3.setBackground(new Color(38,38,38));
		energia3.setForeground(new Color(200,200,200));
		energia.add(energia1);
		energia.add(energia2);
		energia.add(energia3);
	}

}

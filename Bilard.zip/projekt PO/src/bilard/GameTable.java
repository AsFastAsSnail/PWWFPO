package bilard;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GameTable extends JPanel {
	
	Kij kijaszek;
	List<Bila> bile = new ArrayList<Bila>();
	List<List<Bila>> listaList = new ArrayList<List<Bila>>();
	Bila kolizyjna;
	Banda poziome, pionowe;
	private int widthX, heightY;
	private double tarcie;
	private boolean timeFlow;
	//List<Bila> bile = new ArrayList<Bila>();

	public GameTable(int X) {
		//kolizyjna = new Bila();
		tarcie = 0.01;
		widthX = 2*X;
		heightY = X;
		setBackground(new Color(79,143,63));
		bile.add(new Bila(40, widthX/10 , heightY/2 , 1));
		bile.add(new Bila(40, widthX/5 , heightY/4 , 1));
		bile.add(new Bila(40, 8*widthX/50 , heightY/4 , 1));
		//bile.add(new Bila(40, widthX/2 , heightY/2 , 100));
		kijaszek = new Kij(700,70,bile.get(0).getX(),bile.get(0).getY());
		poziome = new Banda(heightY, "pozioma");
		pionowe = new Banda(heightY, "pionowa");
		
	}
	public void setSize(int X, int Y) {
		widthX = X;
		heightY = Y;
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.black);
		pionowe.paint(g2);
		poziome.paint(g2);
		//g2.setColor(new Color(79,143,63));
		//g2.fillRect(poziome.getWidth(), poziome.getWidth(), widthX - 2*poziome.getWidth(), heightY - 2*poziome.getWidth());
		kijaszek.paint(g2);
		g2.setColor(Color.white);
		bile.get(0).paint(g2);
		g2.setColor(Color.black);
		for(int i = 1; i<bile.size();i++) {
			bile.get(i).paint(g2);
		}
		g2.setColor(Color.black);
	}
	public void RunThread() {
		MoveThread thread1 = new MoveThread();
		SavePosition thread2 = new SavePosition();
		thread1.start();
		thread2.start();
	}
	public void checkColision(List<Bila> lista) {
		boolean tryb;
    	for(int i = 0; i<lista.size();i++) {
    		for(int j = 0; j<lista.size(); j++) {
    			if(j!=i && !lista.get(i).zderzenie && !lista.get(j).zderzenie ) {
    				float Energy1 = (float) (lista.get(i).getMass()*(Math.pow(lista.get(i).getxSpeed(), 2) + Math.pow(lista.get(i).getySpeed(), 2))/2); System.out.println(Energy1);
    				float Energy2 = (float) (lista.get(j).getMass()*(Math.pow(lista.get(j).getxSpeed(), 2) + Math.pow(lista.get(j).getySpeed(), 2))/2); System.out.println(Energy2);
    				float distance = (float) Math.abs(((float) Math.pow(Math.abs((lista.get(i).getX() - lista.get(j).getX())), 2) + Math.pow(Math.abs(lista.get(i).getY() - lista.get(j).getY()), 2)));
    				float collisionDistance = (float) Math.pow(lista.get(i).getDiametar()/2 + lista.get(j).getDiametar()/2, 2);
    				if(distance < collisionDistance) {
    					float kat = (float) Math.toDegrees(Math.acos(Math.abs((lista.get(i).getX() - lista.get(j).getX()))/Math.abs(Math.sqrt(distance)))); System.out.println("-----:" + kat);
    					if(lista.get(i).getX()<=lista.get(j).getX() && lista.get(i).getY()<lista.get(j).getY()) {
        					kat += 180;
        				}
    					if(lista.get(i).getX()<lista.get(j).getX() && lista.get(i).getY()>=lista.get(j).getY()) {
        					kat += 90;
        				}
    					if(lista.get(i).getX()>=lista.get(j).getX() && lista.get(i).getY()<lista.get(j).getY()) {
        					
        				}
    					if(lista.get(i).getX()>lista.get(j).getX() && lista.get(i).getY()>=lista.get(j).getY()) {
        					kat += 270;
        				}
    					System.out.println("-----:" + kat);
    					float Xdistance = (float) (Math.sqrt(collisionDistance) - Math.abs(lista.get(i).getX() - lista.get(j).getX()));
    					float Ydistance = (float) (Math.sqrt(collisionDistance) - Math.abs(lista.get(i).getY() - lista.get(j).getY()));
    					if(lista.get(i).getX() <= lista.get(j).getX()) {
    						lista.get(i).setX(lista.get(i).getX() - Xdistance);
    						lista.get(j).setX(lista.get(j).getX() + Xdistance);
    						tryb = false;
    						
    					}
    					if(lista.get(i).getX() >= lista.get(j).getX()) {
    						lista.get(i).setX(lista.get(i).getX() + Xdistance);
    						lista.get(j).setX(lista.get(j).getX() - Xdistance);
    						tryb = true;
    					}
    					if(lista.get(i).getY() <= lista.get(j).getY()) {
    						//lista.get(i).setY(lista.get(i).getY() - Ydistance);
    						//lista.get(j).setY(lista.get(j).getY() + Ydistance);
    						tryb = false;
    						
    					}
    					if(lista.get(i).getY() >= lista.get(j).getY()) {
    						//lista.get(i).setY(lista.get(i).getY() + Xdistance);
    						//lista.get(j).setY(lista.get(j).getY() - Xdistance);
    						tryb = true;
    						
    					}
    					if(tryb = false) {
    						lista.get(i).Hit(Energy2 + 10,180 + kat);
        					lista.get(j).Hit(Energy1 + 10, kat);
    					}
    					if(tryb = true) {
    						lista.get(j).Hit(Energy1 + 10 ,180 + kat);
        					lista.get(i).Hit(Energy2 + 10, kat);
    					}
    					lista.get(i).zderzenie = true;
    					lista.get(j).zderzenie = true;
    					
    				}
    			}
    		}
    	}
    	for(int i=0;i<lista.size();i++) {
    		lista.get(i).zderzenie = false;
    	}
    }
	public boolean check(List<Bila> lista) {
		boolean cosik = true;
		int liczba = 0;
		for(int i = 0;i<lista.size();i++) {
			if(lista.get(i).getxSpeed() == 0) {
				if(lista.get(i).getxSpeed() == 0) {
					liczba++;
				}
			}
		}
		if(liczba == lista.size()) {
			cosik = false;
		}
		return cosik;
	}
	class SavePosition extends Thread{
		public void run() {
			listaList = new ArrayList<List<Bila>>();
			for(int i = 0;i<bile.size();i++) {
				listaList.add(new ArrayList<Bila>());
			}
			boolean zapis = true;
			while(zapis) {
				try {
					for(int i = 0;i<listaList.size();i++) {
						listaList.get(i).add(new Bila(bile.get(i).getDiametar(),bile.get(i).getX(),bile.get(i).getY(),bile.get(i).getMass()));
					}
					TimeUnit.MILLISECONDS.sleep(500);
					zapis = check(bile);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	class MoveThread extends Thread{
		public void run() {
			timeFlow = true;
			while(timeFlow) {
			try {
				for(int i = 0; i<bile.size();i++) {
					bile.get(i).move(widthX, heightY, tarcie, poziome.getWidth());
				}
				/*if(bile.get(0).getX() < 0) {
					String name = JOptionPane.showInputDialog(null,
		                    "Imię", null);
				}*/
				checkColision(bile);
				TimeUnit.MILLISECONDS.sleep(33);
				//System.out.println(bile.get(0).getX() + " * " + bile.get(0).getY());
				repaint();
				timeFlow = check(bile);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
				kijaszek = new Kij(700,70,bile.get(0).getX(),bile.get(0).getY());
				timeFlow = true;
		}
	}
}

package bilard;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.JPanel;

public class GameTable extends JPanel {
	
	Kij kijaszek;
	Bila biala;
	private int widthX, heightY;
	private double tarcie;
	//List<Bila> bile = new ArrayList<Bila>();

	public GameTable(int X, int Y) {
		tarcie = 0.01;
		widthX = X;
		heightY = Y;
		setBackground(new Color(79,143,63));
		biala = new Bila(20, widthX/10 , heightY/2 , 10);
		kijaszek = new Kij(300,70,biala.getX(),biala.getY());
	}
	public void setSize(int X, int Y) {
		widthX = X;
		heightY = Y;
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.white);
		biala.paint(g2);
		g2.setColor(Color.black);
		kijaszek.paint(g2);
	}
	public void RunThread() {
		MoveThread thread1 = new MoveThread();
		thread1.start();
	}
	class MoveThread extends Thread{
		public void run() {
			while(true) {
			try {
				TimeUnit.MILLISECONDS.sleep(100);
				biala.move(widthX, heightY, tarcie);
				System.out.println(" * ");
				repaint();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	}
}

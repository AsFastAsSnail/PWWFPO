package bilard;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

public class GameWindow extends JFrame{
GameTable stol;
SliderPanel sliPan;
BMenuBar menu;
ScoreWindow punktacja;
TimeTable stolik;
JSlider czas;
	public GameWindow(int widthX, int widthY){
		super();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(widthX, widthY);
		setUndecorated(true);
		setLayout(new BorderLayout());
		
		menu = new BMenuBar();
		menu.mExit.addActionListener(new Exit());
		menu.forceMove.addActionListener(new ForceMove());
		menu.timeWindow.addActionListener(new TimeWindow());
		setJMenuBar(menu);
		
		stol = new GameTable(getHeight());
		add(stol, BorderLayout.CENTER);
		
		sliPan = new SliderPanel(200);
		sliPan.kat.addChangeListener(new AngleListener());
		sliPan.uderzenie.addActionListener(new Hit());
		add(sliPan, BorderLayout.LINE_END);
		
		punktacja = new ScoreWindow();
		add(punktacja, BorderLayout.PAGE_END);
	}

	class Exit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			punktacja.pause();
			System.exit(0);
		}
	}
	class ForceMove implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			stol.bile.get(0).setxSpeed(0);
			stol.bile.get(0).setySpeed(0);
			stol.bile.get(0).setX(-110);
		}
	}
	class Hit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			stol.bile.get(0).Hit(sliPan.energia.getValue(), sliPan.kat.getValue());
			//stol.bile.get(2).Hit(sliPan.energia.getValue(),180 + sliPan.kat.getValue());
			stol.kijaszek = new Kij(300,70,-1000,-1000);
			stol.RunThread();
			sliPan.kat.setValue(0);
		}
	}
	class AngleListener implements ChangeListener{
		@Override
		public void stateChanged(ChangeEvent arg0) {
			stol.kijaszek.getAngle(sliPan.kat.getValue());
			stol.repaint();
		}
	}
	class TimeChanger implements ChangeListener{
		@Override
		public void stateChanged(ChangeEvent arg0) {
			stolik.changeTime(czas.getValue());
		}
	}
	class TimeWindow implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			if(stol.listaList.get(0).size() > 0) {
				JFrame f = new JFrame("Prostokaty");
				f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				f.setSize(1200,600);
				f.setLayout(new BorderLayout());
				czas = new JSlider(JSlider.HORIZONTAL, 0, stol.listaList.get(0).size() - 1, stol.listaList.get(0).size() - 1);
				czas.addChangeListener(new TimeChanger());
				stolik = new TimeTable(600, stol.listaList);
				f.add(stolik, BorderLayout.CENTER);
				f.add(czas,BorderLayout.PAGE_END);
				
				f.setVisible(true);
			}
			else JOptionPane.showMessageDialog(null, "Brak zdarzeń do pokazania");
		}
	}
	public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				GameWindow window = new GameWindow(1200,600);
				window.setVisible(true);
				window.punktacja.runThread();	
			}
		});
		
		
	}
}

package bilard;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

public class GameWindow extends JFrame{
GameTable stol;
SliderPanel sliPan;
BMenuBar menu;
ScoreWindow punktacja;
	public GameWindow(int widthX, int widthY){
		super();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(widthX,widthY);
		setUndecorated(true);
		setLayout(new BorderLayout());
		
		menu = new BMenuBar();
		menu.mExit.addActionListener(new Exit());
		setJMenuBar(menu);
		
		stol = new GameTable(getWidth(),getHeight());
		add(stol, BorderLayout.CENTER);
		
		sliPan = new SliderPanel(50);
		sliPan.kat.addChangeListener(new AngleListener());
		sliPan.uderzenie.addActionListener(new Hit());
		add(sliPan, BorderLayout.LINE_END);
		
		punktacja = new ScoreWindow();
		add(punktacja, BorderLayout.PAGE_END);
	}

	class Exit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			System.exit(0);
		}
	}
	class Hit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			stol.biala.Hit(sliPan.energia.getValue(), sliPan.kat.getValue());
			stol.RunThread();
		}
	}
	class AngleListener implements ChangeListener{
		@Override
		public void stateChanged(ChangeEvent arg0) {
			stol.kijaszek.getAngle(sliPan.kat.getValue());
			stol.repaint();
		}
	}
	public static void main(String[] args){
		GameWindow window = new GameWindow(1000,500);
		window.setVisible(true);
		window.punktacja.runThread();
		
	}
}

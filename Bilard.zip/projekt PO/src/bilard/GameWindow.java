package bilard;

import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;

public class GameWindow extends JFrame{
JPanel stol;
SliderPanel sliPan;
BMenuBar menu;
	public GameWindow(){
		super();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		setUndecorated(true);
		setLayout(new BorderLayout());
		
		menu = new BMenuBar();
		menu.mExit.addActionListener(new Exit());
		setJMenuBar(menu);
		
		stol = new JPanel();
		stol.setBackground(new Color(79,143,63));
		add(stol, BorderLayout.CENTER);
		
		sliPan = new SliderPanel(50);
		add(sliPan, BorderLayout.LINE_END);
		
		
	}

	class Exit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			dispose();
		}
	}
	public static void main(String[] args){
		GameWindow window = new GameWindow();
		
		window.setVisible(true);
	}
}

package bilard;

import javax.swing.*;


import java.awt.*;
import java.awt.Color;

public class SliderPanel extends JPanel{
JSlider kat, energia;
JLabel labkat, labenergia;
JPanel pan1, pan2, pan3;
JButton uderzenie;
	public SliderPanel(int maksE) {
		super();
		setLayout(new BorderLayout());
		pan1 = new JPanel();
		pan1.setBackground(new Color(200,200,200));
		pan1.setLayout(new GridLayout(1,2));
		labkat = new JLabel("Kąt");
		labenergia = new JLabel("Energia");
		pan1.add(labkat);
		pan1.add(labenergia);
		add(pan1, BorderLayout.PAGE_START);
		
		pan2 = new JPanel();
		
		pan2.setLayout(new GridLayout(1,2));
		kat = new JSlider(JSlider.VERTICAL, -180, 180, 0);
		kat.setBackground(new Color(200,200,200));
		kat.setForeground(new Color(38,38,38));
		kat.setMajorTickSpacing(30);
		kat.setPaintTicks(true);
		kat.setPaintLabels(true);	
		energia = new JSlider(JSlider.VERTICAL, 0, maksE, 0);
		energia.setBackground(new Color(200,200,200));
		energia.setForeground(new Color(38,38,38));
		energia.setMajorTickSpacing(10);
		energia.setPaintTicks(true);
		energia.setPaintLabels(true);
		pan2.add(kat);
		pan2.add(energia);
		add(pan2, BorderLayout.CENTER);
		
		pan3 = new JPanel();
		pan3.setBackground(new Color(200,200,200));
		uderzenie = new JButton("Uderzenie");
		pan3.add(uderzenie);
		add(pan3, BorderLayout.PAGE_END);
		
	}
	

}

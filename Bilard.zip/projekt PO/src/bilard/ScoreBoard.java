package bilard;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;

public class ScoreBoard extends JFrame{
	List<JTextField> fieldx, fieldy, fieldz;
	JMenuBar exitmb;
	JMenu exitm;
	JMenuItem exit;
	public ScoreBoard() {
		super();
		setSize(640,480);
		setUndecorated(true);
		exitmb = new JMenuBar();
		exitm = new JMenu("Menu");
		exitmb.add(exitm);
		exit = new JMenuItem("Exit");
		exitm.add(exit);
		exit.addActionListener(new Exit());
		setJMenuBar(exitmb);
		setLayout(new GridLayout(10,3));
		fieldx = new ArrayList<JTextField>();
		fieldy = new ArrayList<JTextField>();
		fieldz = new ArrayList<JTextField>();
		for(int i = 0; i < 10 ;i++) {
			fieldx.add(new JTextField("Imię"));
			add(fieldx.get(i));
			fieldy.add(new JTextField("Czas"));
			add(fieldy.get(i));
			fieldz.add(new JTextField("Wynik"));
			add(fieldz.get(i));
		}
		
		
		
	}
	class Exit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			dispose();
		}
	}
public static void main(String[] args) {
	ScoreBoard board = new ScoreBoard();
	board.setVisible(true);
}
}

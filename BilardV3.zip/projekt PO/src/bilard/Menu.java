package bilard;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;

import javax.swing.event.*;

public class Menu extends JFrame implements ActionListener {

	JButton but1, but2, but3;
	JLabel lab1;
	JPanel pan1, pan2, pan3, pan4, pan5;
	Image image;
	ActionListener Exit = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			System.exit(0);
		}	
	};
	
	ActionListener Score = new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent arg0) {
			try {
				ScoreBoard.main(null);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dispose();
		}
	};
	
	public Menu() {
		
		super();
		File imageFile = new File("Tlo.png");
    	try {
			image = (ImageIO.read(imageFile));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setUndecorated(true);
		pan1 = new JPanel();
		pan2 = new JPanel();
		pan3 = new JPanel();
		pan4 = new JPanel();
		pan5 = new JPanel();
		pan1.setLayout(new FlowLayout());
		pan2.setLayout(new FlowLayout());
		pan3.setLayout(new FlowLayout());
		pan4.setLayout(new FlowLayout());
		pan5.setLayout(new FlowLayout());
		
		this.setLayout(new GridLayout(5,1));
		this.setSize(640,480);
		pan1.setBackground(new Color(79,143,63));
		pan2.setBackground(new Color(79,143,63));
		pan3.setBackground(new Color(79,143,63));
		pan4.setBackground(new Color(79,143,63));
		pan5.setBackground(new Color(79,143,63));
		lab1 = new JLabel("Bilard");
		lab1.setFont(new Font("Comic Sans MS",Font.BOLD,70));
		lab1.setForeground(new Color(38,38,38));
		but1 = new JButton("Nowa gra");
		but1.setFont(new Font("Comic Sans MS",Font.ITALIC,16));
		but1.setForeground(new Color(79,143,63));
		but1.setBackground(new Color(38,38,38));
		but2 = new JButton("Tabela wyników");
		but2.addActionListener(Score);
		but2.setFont(new Font("Comic Sans MS",Font.ITALIC,16));
		but2.setForeground(new Color(79,143,63));
		but2.setBackground(new Color(38,38,38));
		but3 = new JButton("Wyjście");
		but3.setFont(new Font("Comic Sans MS",Font.ITALIC,16));
		but3.setForeground(new Color(79,143,63));
		but3.setBackground(new Color(38,38,38));
		
		this.add(pan1);
		this.add(pan5);
		this.add(pan2);
		this.add(pan3);
		this.add(pan4);
		
		pan1.add(lab1);
		pan2.add(but1);
		pan3.add(but2);
		pan4.add(but3);
		but1.addActionListener(this);
		but3.addActionListener(Exit);
	}
	public void paintComponent(Graphics g) {
		//super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.black);
		g2.drawImage(image, 0, 0, 480, 640, null);
	}
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Menu frame = new Menu();
				frame.setVisible(true);
			}
		});
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		GameWindow.main(null);
		dispose();
	}

}
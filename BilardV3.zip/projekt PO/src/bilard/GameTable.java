package bilard;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GameTable extends JPanel {
	
	Trojkat bille;
	Kij kijaszek;
	List<Bila> bile = new ArrayList<Bila>();
	List<List<Bila>> listaList = new ArrayList<List<Bila>>();
	Bila kolizyjna;
	Banda poziome, pionowe;
	ScoreWindow punktacja;
	private int widthX, heightY;
	private double tarcie;
	private boolean timeFlow;
	int score;
	Random gen;
	Image image;
	//List<Bila> bile = new ArrayList<Bila>();

	public GameTable(int X) {
		File imageFile = new File("Stol.png");
    	try {
			image = (ImageIO.read(imageFile));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		setLayout(new BorderLayout());
		score = 0;
		gen = new Random();
		//kolizyjna = new Bila();
		tarcie = 0.01;
		widthX = 2*X;
		heightY = X;
		setBackground(new Color(79,143,63));
		//Dodanie bill
		bile.add(new Bila(35, widthX/10 , heightY/2 , 1, Color.white));
		bille = new Trojkat(3*widthX/4,101*heightY/200,35);
		for(int i=0;i<4;i++) {
			bile.add(new Bila(bille.diametar, bille.Xy[i], bille.Yy[i], 1, new Color(176,43,28)));
		}
		bile.add(new Bila(bille.diametar, bille.Xy[4], bille.Yy[4], 1, new Color(0,0,0)));
		for(int i=5;i<10;i++) {
			bile.add(new Bila(bille.diametar, bille.Xy[i], bille.Yy[i], 1, new Color(176,43,28)));
		}
		bile.add(new Bila(bille.diametar, bille.Xy[10], bille.Yy[10], 1, new Color(0,0,205)));
		bile.add(new Bila(bille.diametar, bille.Xy[11], bille.Yy[11], 1, new Color(255,255,0)));
		bile.add(new Bila(bille.diametar, bille.Xy[12], bille.Yy[12], 1, new Color(255,140,0)));
		bile.add(new Bila(bille.diametar, bille.Xy[14], bille.Yy[14], 1, new Color(0,128,0)));
		bile.add(new Bila(bille.diametar, bille.Xy[13], bille.Yy[13], 1, new Color(139,69,19)));
		
		kijaszek = new Kij(700,70,bile.get(0).getX(),bile.get(0).getY());
		poziome = new Banda(heightY, "pozioma");
		pionowe = new Banda(heightY, "pionowa");
		punktacja = new ScoreWindow();
		add(punktacja, BorderLayout.PAGE_END);
	}
	public void setSize(int X, int Y) {
		widthX = X;
		heightY = Y;
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.black);
		g2.drawImage(image, 0, 0, widthX, heightY, null);
		//pionowe.paint(g2);
		//poziome.paint(g2);
		//g2.setColor(new Color(79,143,63));
		//g2.fillRect(poziome.getWidth(), poziome.getWidth(), widthX - 2*poziome.getWidth(), heightY - 2*poziome.getWidth());
		
		for(int i = 0; i<bile.size();i++) {
			g2.setColor(bile.get(i).kolor);
			bile.get(i).paint(g2);
		}
		g2.setColor(Color.black);
		kijaszek.paint(g2);
	}
	public void RunThread() {
		MoveThread thread1 = new MoveThread();
		SavePosition thread2 = new SavePosition();
		thread1.start();
		thread2.start();
	}
	public void checkColision(List<Bila> lista) {
		boolean tryb;
    	for(int i = 0; i<lista.size();i++) {
    		for(int j = 0; j<lista.size(); j++) {
    			if(j!=i && !lista.get(i).zderzenie && !lista.get(j).zderzenie ) {
    				float Energy1 = (float) (lista.get(i).getMass()*(Math.pow(lista.get(i).getxSpeed(), 2) + Math.pow(lista.get(i).getySpeed(), 2))/2); System.out.println(Energy1);
    				float Energy2 = (float) (lista.get(j).getMass()*(Math.pow(lista.get(j).getxSpeed(), 2) + Math.pow(lista.get(j).getySpeed(), 2))/2); System.out.println(Energy2);
    				float distance = (float) Math.abs(((float) Math.pow(Math.abs((lista.get(i).getX() - lista.get(j).getX())), 2) + Math.pow(Math.abs(lista.get(i).getY() - lista.get(j).getY()), 2)));
    				float collisionDistance = (float) Math.pow(lista.get(i).getDiametar()/2 + lista.get(j).getDiametar()/2, 2);
    				if(distance < collisionDistance) {
    					float kat = (float) Math.toDegrees(Math.acos(Math.abs((lista.get(i).getX() - lista.get(j).getX()))/Math.abs(Math.sqrt(distance)))); System.out.println("-----:" + kat);
    					if(lista.get(i).getX()<=lista.get(j).getX() && lista.get(i).getY()<lista.get(j).getY()) {
        					kat += 180;
        				}
    					if(lista.get(i).getX()<lista.get(j).getX() && lista.get(i).getY()>=lista.get(j).getY()) {
        					kat += 90;
        				}
    					if(lista.get(i).getX()>=lista.get(j).getX() && lista.get(i).getY()>lista.get(j).getY()) {
    						
        				}
    					if(lista.get(i).getX()>lista.get(j).getX() && lista.get(i).getY()<=lista.get(j).getY()) {
    						kat += 270;
        				}
    					System.out.println("-----:" + kat);
    					//float Xdistance = (float) (Math.sqrt(collisionDistance) - Math.abs(lista.get(i).getX() - lista.get(j).getX()));
    					//float Ydistance = (float) (Math.sqrt(collisionDistance) - Math.abs(lista.get(i).getY() - lista.get(j).getY()));
    					if(lista.get(i).getX() <= lista.get(j).getX()) {
    						//lista.get(i).setX(lista.get(i).getX() - Xdistance);
    						//lista.get(j).setX(lista.get(j).getX() + Xdistance);
    						tryb = false;
    						
    					}
    					if(lista.get(i).getX() >= lista.get(j).getX()) {
    						//lista.get(i).setX(lista.get(i).getX() + Xdistance);
    						//lista.get(j).setX(lista.get(j).getX() - Xdistance);
    						tryb = true;
    					}
    					if(lista.get(i).getY() <= lista.get(j).getY()) {
    						//lista.get(i).setY(lista.get(i).getY() - Ydistance);
    						//lista.get(j).setY(lista.get(j).getY() + Ydistance);
    						tryb = false;
    						
    					}
    					if(lista.get(i).getY() >= lista.get(j).getY()) {
    						//lista.get(i).setY(lista.get(i).getY() + Xdistance);
    						//lista.get(j).setY(lista.get(j).getY() - Xdistance);
    						tryb = true;
    						
    					}
    					if(tryb = false) {
    						lista.get(i).hit(Energy2 + 10,180 + kat);
        					lista.get(j).hit(Energy1 + 10, kat);
    					}
    					if(tryb = true) {
    						lista.get(j).hit(9*Energy1/10 + Energy2/10 ,180 + kat);
        					lista.get(i).hit(9*Energy2/10 + Energy1/10 , kat);
    					}
    					lista.get(i).zderzenie = true;
    					lista.get(j).zderzenie = true;
    					
    				}
    			}
    		}
    	}
    	for(int i=0;i<lista.size();i++) {
    		lista.get(i).zderzenie = false;
    	}
    }
	public boolean check(List<Bila> lista) {
		boolean cosik = true;
		int liczba = 0;
		for(int i = 0;i<lista.size();i++) {
			if(lista.get(i).getxSpeed() == 0) {
				if(lista.get(i).getySpeed() == 0) {
					liczba++;
				}
			}
		}
		if(liczba == lista.size()) {
			cosik = false;
		}
		return cosik;
	}
	class SavePosition extends Thread{
		public void run() {
			listaList = new ArrayList<List<Bila>>();
			for(int i = 0;i<bile.size();i++) {
				listaList.add(new ArrayList<Bila>());
			}
			boolean zapis = true;
			while(zapis) {
				try {
					for(int i = 0;i<listaList.size();i++) {
						listaList.get(i).add(new Bila(bile.get(i).getDiametar(),bile.get(i).getX(),bile.get(i).getY(),bile.get(i).getMass(), bile.get(i).kolor));
						
					}
					TimeUnit.MILLISECONDS.sleep(500);
					zapis = check(bile);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	class MoveThread extends Thread{
		public void run() {
			timeFlow = true;
			while(timeFlow) {
			try {
				for(int i = 0; i<bile.size();i++) {
					bile.get(i).move(widthX, heightY, tarcie, poziome.getWidth());
					if((bile.get(i).getY() < poziome.getWidth() || bile.get(i).getY() > heightY - poziome.getWidth()) && !(bile.get(i).getX()<0)) {
						bile.get(i).stop(); punktacja.addScore();
					}
				}
				/*if(bile.get(0).getX() < 0) {
					String name = JOptionPane.showInputDialog(null,
		                    "Imię", null);
				}*/
				checkColision(bile);
				TimeUnit.MILLISECONDS.sleep(33);
				//System.out.println(bile.get(0).getX() + " * " + bile.get(0).getY());
				repaint();
				timeFlow = check(bile);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
				kijaszek = new Kij(700,70,bile.get(0).getX(),bile.get(0).getY());
				
		}
	}
}

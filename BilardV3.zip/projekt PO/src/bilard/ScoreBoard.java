package bilard;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import javax.swing.JTextPane;

public class ScoreBoard extends JFrame{
	JTextPane text;
	JMenuBar exitmb;
	JMenu exitm;
	JMenuItem exit;
	String tekst;
	public ScoreBoard() throws IOException {
		super();
		setSize(640,480);
		setUndecorated(true);
		exitmb = new JMenuBar();
		exitm = new JMenu("Menu");
		exitmb.add(exitm);
		exit = new JMenuItem("Exit");
		exitm.add(exit);
		exit.addActionListener(new Exit());
		setJMenuBar(exitmb);
		BufferedReader input = new BufferedReader(new InputStreamReader(new FileInputStream("wyniki.txt"),Charset.forName("UTF-8").newDecoder()));
		StringBuilder build = new StringBuilder();
		while((tekst = input.readLine()) != null)build.append(tekst + System.getProperty("line.separator"));
		tekst = build.toString();
		input.close();
		text = new JTextPane();
		text.setText(tekst);
		
		
		
	}
	class Exit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			dispose();
			Menu.main(null);
		}
	}
public static void main(String[] args) throws IOException {
	ScoreBoard board = new ScoreBoard();
	board.setVisible(true);
}
}

package bilard;

import java.util.List;

public class Trojkat {
	float[] Xy;
	float[] Yy;
	float diametar;
	public Trojkat(float X, float Y, float diam) {
		diametar = diam;
		float distance = 16*diametar/20;
		Xy = new float[15];
		Xy[0] = X - 2*distance;
		
		Xy[1] = X - distance;
		Xy[2] = Xy[1];
		
		Xy[3] = X;
		Xy[4] = Xy[3];
		Xy[5] = Xy[3];
		
		Xy[6] = X + distance;
		Xy[7] = Xy[6];
		Xy[8] = Xy[6];
		Xy[9] = Xy[6];
		
		Xy[10] = X + 2*distance;
		Xy[11] = Xy[10];
		Xy[12] = Xy[10];
		Xy[13] = Xy[10];
		Xy[14] = Xy[10];
		
		Yy = new float[15];
		Yy[0] = Y;
		
		Yy[1] = Y - distance;
		Yy[2] = Y + distance;
		
		Yy[3] = Yy[0] - 2*distance;
		Yy[4] = Yy[0];
		Yy[5] = Yy[0] + 2*distance;
		
		Yy[6] = Yy[1] - 2*distance;
		Yy[7] = Yy[1];
		Yy[8] = Yy[2];
		Yy[9] = Yy[2] + 2*distance;
		
		Yy[10] = Yy[3] - 2*distance;
		Yy[11] = Yy[3];
		Yy[12] = Yy[0];
		Yy[13] = Yy[5];
		Yy[14] = Yy[5] + 2*distance;
		
		
		
	}

}

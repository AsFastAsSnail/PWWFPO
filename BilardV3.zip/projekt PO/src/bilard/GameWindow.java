package bilard;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.concurrent.TimeUnit;

public class GameWindow extends JFrame{
GameTable stol;
SliderPanel sliPan;
BMenuBar menu;

TimeTable stolik;
JSlider czas;
	public GameWindow(int widthX, int widthY){
		super();
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		setSize(widthX, widthY);
		setUndecorated(true);
		setLayout(new BorderLayout());
		
		menu = new BMenuBar();
		menu.mExit.addActionListener(new Exit());
		menu.forceMove.addActionListener(new ForceMove());
		menu.timeWindow.addActionListener(new TimeWindow());
		setJMenuBar(menu);
		
		stol = new GameTable(550);
		add(stol, BorderLayout.CENTER);
		
		sliPan = new SliderPanel(200);
		sliPan.kat.addChangeListener(new AngleListener());
		sliPan.uderzenie.addActionListener(new Hit());
		add(sliPan, BorderLayout.LINE_END);
		
		
	}

	class Exit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			stol.punktacja.pause();
			Menu.main(null);
			dispose();
		}
	}
	class ForceMove implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			stol.bile.get(0).stop();
		}
	}
	class Hit implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			stol.bile.get(0).hit(sliPan.energia.getValue(), sliPan.kat.getValue());
			//stol.bile.get(2).Hit(sliPan.energia.getValue(),180 + sliPan.kat.getValue());
			stol.kijaszek = new Kij(300,70,-1000,-1000);
			stol.RunThread();
			sliPan.kat.setValue(0);
		}
	}
	class AngleListener implements ChangeListener{
		@Override
		public void stateChanged(ChangeEvent arg0) {
			stol.kijaszek.getAngle(sliPan.kat.getValue());
			stol.repaint();
		}
	}
	class TimeChanger implements ChangeListener{
		@Override
		public void stateChanged(ChangeEvent arg0) {
			stolik.changeTime(czas.getValue());
		}
	}
	class Checker extends Thread{
		public void run() {
			while(true) {
			try {
				TimeUnit.SECONDS.sleep(1);
				if(stol.bile.get(0).getX() < 0) {
					String name = JOptionPane.showInputDialog(null, "Biała bila wbita, koniec gry. Twój wynik: " + stol.punktacja.time.getText() + stol.punktacja.score.getText());
					stol.bile.get(0).setX(10000);
					OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream("wyniki.txt"));
					writer.append(name + " " + stol.punktacja.time.getText() + " " + stol.punktacja.score.getText() + System.getProperty("line.separator"));
					writer.close();
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
		}
	}
	public void runChecker() {
		Checker check = new Checker();
		check.start();
	}
	class TimeWindow implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			if(stol.listaList.get(0).size() > 0) {
				JFrame f = new JFrame("Prostokaty");
				f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				f.setSize(1200,600);
				f.setLayout(new BorderLayout());
				czas = new JSlider(JSlider.HORIZONTAL, 0, stol.listaList.get(0).size() - 1, stol.listaList.get(0).size() - 1);
				czas.addChangeListener(new TimeChanger());
				stolik = new TimeTable(550, stol.listaList);
				f.add(stolik, BorderLayout.CENTER);
				f.add(czas,BorderLayout.PAGE_END);
				
				f.setVisible(true);
			}
			else JOptionPane.showMessageDialog(null, "Brak zdarzeń do pokazania");
		}
	}
	public static void main(String[] args){
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				GameWindow window = new GameWindow(1200,590);
				window.setVisible(true);
				window.stol.punktacja.runThread();	
				window.runChecker();
			}
		});
		
		
	}
}

package bilard;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

public class Banda {
	private int WidthX, HeightY, grubosc, x, y;
	private double x1, x2, x3, x4, x5, x6, y1, y2, y3, y4, y5, y6, r;
	
	public Banda(int Height, String orient) {
		grubosc = 2*Height/21;
		if(orient.contentEquals("pozioma")) {
			WidthX = 2*Height;
			HeightY = grubosc;
			r = (int) grubosc*2.5;
			x = 0;
			y = Height - grubosc;
			x1 = grubosc/2; x2 = WidthX/2; x3 = WidthX - grubosc/2; x4 = grubosc/2; x5 = WidthX/2; x6 = WidthX - grubosc/2;
			y1 = grubosc/2; y2 = grubosc/2; y3 = grubosc/2; y4 = Height - grubosc/2; y5 = Height - grubosc/2; y6 = Height - grubosc/2;
		}
		if(orient.contentEquals("pionowa")) {
			HeightY = Height;
			WidthX = grubosc;
			r = (int) grubosc*2.5;
			x = 2*Height - grubosc;
			y = 0;
			x1 = -100;x2 = -100;x3 = -100;x4 = -100;x5 = -100;x6 = -100;
			y1 = -100;y2 = -100;y3 = -100;y4 = -100;y5 = -100;y6 = -100;
		}
	}
	public int getWidth() {
		return grubosc;
	}
	public void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(new Color(165,42,42));
		g2.fillRect(0, 0, WidthX, HeightY);
		g2.fillRect(x, y, WidthX, HeightY);
		g2.setColor(Color.black);
        Ellipse2D.Double circle1 = new Ellipse2D.Double(x1 - r / 2, y1 - r / 2, r, r);
        Ellipse2D.Double circle2 = new Ellipse2D.Double(x2 - r / 2, y2 - r / 2, r, r);
        Ellipse2D.Double circle3 = new Ellipse2D.Double(x3 - r / 2, y3 - r / 2, r, r);
        Ellipse2D.Double circle4 = new Ellipse2D.Double(x4 - r / 2, y4 - r / 2, r, r);
        Ellipse2D.Double circle5 = new Ellipse2D.Double(x5 - r / 2, y5 - r / 2, r, r);
        Ellipse2D.Double circle6 = new Ellipse2D.Double(x6 - r / 2, y6 - r / 2, r, r);
        g2.fill(circle1);
        g2.fill(circle2);
        g2.fill(circle3);
        g2.fill(circle4);
        g2.fill(circle5);
        g2.fill(circle6);
	}
}

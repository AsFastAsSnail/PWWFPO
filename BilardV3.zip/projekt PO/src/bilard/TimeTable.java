package bilard;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;



public class TimeTable extends JPanel{
	
	private int widthX, heightY;
	int numer;
	Banda poziome, pionowe;
	List<List<Bila>> listaList = new ArrayList<List<Bila>>();
	Image image;
	public TimeTable(int X, List<List<Bila>> lista) {
		File imageFile = new File("Stol.png");
    	try {
			image = (ImageIO.read(imageFile));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		numer = lista.get(0).size() - 1;
		listaList = lista;
		widthX = 2*X;
		heightY = X;
		setBackground(new Color(79,143,63));
		poziome = new Banda(heightY, "pozioma");
		pionowe = new Banda(heightY, "pionowa");
	}
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.black);
		g2.drawImage(image, 0, 0, widthX, heightY, null);
		//pionowe.paint(g2);
		//poziome.paint(g2);
		for(int i = 0; i<listaList.size();i++) {
			g2.setColor(listaList.get(i).get(numer).kolor);
			listaList.get(i).get(numer).paint(g2);
		}
		g2.setColor(Color.black);
	}
	public void changeTime(int I) {
		numer = I;
		repaint();
	}
}
